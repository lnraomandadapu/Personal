﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Data
{
    public sealed class SyncDbManager
    {
        private FbConnection _dbConnection;

        public SyncDbManager()
        {
            _dbConnection = SyncDbFactory.GetDbConnection();
        }

        /// <summary>
        /// open connection
        /// </summary>
        private void Open()
        {
            if (_dbConnection != null && _dbConnection.State == ConnectionState.Closed)
            {
                _dbConnection.Open();
            }
        }

        /// <summary>
        /// close connection
        /// </summary>
        private void Close()
        {
            if (_dbConnection != null && _dbConnection.State != ConnectionState.Closed)
            {
                _dbConnection.Close();
            }
        }

        /// <summary>
        /// Get Data
        /// </summary>
        /// <param name="queryText"></param>
        /// <param name="fbParams"></param>
        /// <returns></returns>
        public DataSet GetDataWithQuery(string queryText, FbParameter[] fbParams = null)
        {
            DataSet dataResults = new DataSet();
            try
            {
                using (var dataCommand = SyncDbFactory.GetDbCommand(_dbConnection, queryText, CommandType.Text))
                {
                    if (fbParams != null)
                    {
                        dataCommand.Parameters.AddRange(fbParams);
                    }
                    using (var dataAdapter = SyncDbFactory.GetDbAdapter(dataCommand))
                    {
                        dataAdapter.Fill(dataResults);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return dataResults;
        }

        public DataSet GetDataWithProcrdure(string procName, FbParameter[] fbParams = null)
        {
            DataSet dataResults = new DataSet();
            try
            {
                using (var dataCommand = SyncDbFactory.GetDbCommand(_dbConnection, procName, CommandType.StoredProcedure))
                {
                    if (fbParams != null)
                    {
                        dataCommand.Parameters.AddRange(fbParams);
                    }
                    using (var dataAdapter = SyncDbFactory.GetDbAdapter(dataCommand))
                    {
                        dataAdapter.Fill(dataResults);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }


            return dataResults;
        }

        /// <summary>
        /// Modify Data
        /// </summary>
        /// <param name="queryText"></param>
        /// <param name="fbParams"></param>
        /// <returns></returns>
        public bool ModifyDataWithQuery(string queryText, FbParameter[] fbParams = null)
        {
            bool isSuccess = true;
            try
            {

                using (var dataCommand = SyncDbFactory.GetDbCommand(_dbConnection, queryText, CommandType.Text))
                {
                    if (fbParams != null)
                    {
                        dataCommand.Parameters.AddRange(fbParams);
                    }
                    this.Open();
                    dataCommand.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                isSuccess = false;
                throw;
            }
            finally
            {
                this.Close();
            }

            return isSuccess;
        }


        public void ExecuteScalarWithQuery(string queryText, FbParameter[] fbParams = null)
        {
            try
            {
                using (var dataCommand = SyncDbFactory.GetDbCommand(_dbConnection, queryText, CommandType.Text))
                {
                    if (fbParams != null)
                    {
                        dataCommand.Parameters.Add(fbParams);
                    }
                    this.Open();
                    dataCommand.ExecuteScalar();

                }
            }
            catch (Exception)
            {

                throw;
            }
            this.Close();

        }
    }
}
