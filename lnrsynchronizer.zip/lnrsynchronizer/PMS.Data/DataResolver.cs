﻿using BasicBookingSystem.Model.PMSDataAccessWrapper;
using PMS.DependencyResolver;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Data
{
    [Export(typeof(IComponent))]
    public class DataResolver : IComponent
    {
        public void SetUp(IRegisterComponent registerComponent)
        {
            registerComponent.RegisterType<IPmsSyncDataAccess, PmsSyncDataAccess>();
        }
    }
}
