﻿using BasicBookingSystem.Model;
using BasicBookingSystem.Model.PMSDataAccessWrapper;
using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace PMS.Data
{
    public class PmsSyncDataAccess: IPmsSyncDataAccess
    {

        private SyncDbManager _syncDbManager;
        private int _pmsId = 0;
        private int _slotSyncInterval = 0;

        public PmsSyncDataAccess()
        {
            _syncDbManager = new SyncDbManager();
            _pmsId = Helper.GetAppSetting("PmsId").TypeCastTo<int>();
            _slotSyncInterval = Helper.GetAppSetting("SlotSyncMonthInterval").TypeCastTo<int>(); 
        }
        /// <summary>
        /// Get doctors information
        /// </summary>
        /// <returns></returns>
        public List<PMSCalendarWithSlots> GetCalendarData()
        {
            List<PMSCalendarWithSlots> calendars = new List<PMSCalendarWithSlots>();
            try
            {
                var calendarData = _syncDbManager.GetDataWithQuery(DbConstantsHelper.FETCH_SCHEDULES_QUERY);

                if (calendarData != null)
                {
                    if (calendarData.Tables != null && calendarData.Tables.Count > 0)
                    {
                        if (calendarData.Tables[0].Rows.Count > 0)
                        {
                            DataView docSchedule = new DataView(calendarData.Tables[0]);
                            List<DataRow> distinctDoctors = docSchedule.ToTable(true, "DOCTOR_CODE", "GIVEN_NAME", "FAMILY_NAME").AsEnumerable().ToList();
                            foreach (var doctor in distinctDoctors)
                            {
                                calendars.Add(this.PrepareSchedules(doctor, calendarData.Tables[0]));
                            }


                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return calendars;

        }

        /// <summary>
        /// prepare shcedule for each doctoe code
        /// </summary>
        /// <param name="doctor"></param>
        /// <param name="docSchedule"></param>
        /// <returns></returns>
        private PMSCalendarWithSlots PrepareSchedules(DataRow doctor, DataTable docSchedule)
        {
            PMSCalendarWithSlots calendar = new PMSCalendarWithSlots();
            if (doctor != null && docSchedule != null)
            {
                var docDayWiseSchedule = docSchedule.AsEnumerable().Where(row => row.Field<string>("DOCTOR_CODE") == doctor["DOCTOR_CODE"].ToString()).ToList();
                if (docDayWiseSchedule != null)
                {
                    calendar.PMSCalendarName = string.Format("{0}, {1}", doctor["GIVEN_NAME"], doctor["FAMILY_NAME"]);
                    calendar.PMSCalendarCode = doctor["DOCTOR_CODE"].ToString();
                    calendar.PMSId = _pmsId;
                    calendar.Slots = this.GenerateSchedule(docDayWiseSchedule, calendar.PMSCalendarCode);

                }
            }
            return calendar;
        }


        /// <summary>
        /// get booked slots based on doctor and target date.
        /// </summary>
        /// <param name="doctorCode"></param>
        /// <param name="targetDate"></param>
        /// <returns></returns>
        private List<Slot> GetDoctorBookedSlotsForDate(string doctorCode, DateTime targetDate)
        {
            try
            {
                var fbParams = new FbParameter[]
                {
                    new FbParameter(DbConstantsHelper.TARGET_DATE_PARAM,targetDate.Date.ToString("yyyy/MM/dd")),
                    new FbParameter(DbConstantsHelper.DOCTOR_CODE_PARAM,doctorCode),
                };
                return this.GetBookedSlots(_syncDbManager.GetDataWithQuery(string.Format(DbConstantsHelper.FETCH_BOOKED_SLOTS, DbConstantsHelper.DOCTOR_CODE_PARAM, DbConstantsHelper.TARGET_DATE_PARAM), fbParams));
                
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// get booked slots
        /// </summary>
        /// <param name="bookings"></param>
        /// <returns></returns>
        private List<Slot> GetBookedSlots(DataSet bookings)
        {
            List<Slot> bookedSlots = new List<Slot>();
            if (bookings != null && bookings.Tables.Count > 0)
            {
                if (bookings.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dataRow in bookings.Tables[0].Rows)
                    {
                        bookedSlots.Add(new Slot() { StartTime = dataRow["START_POINT"].TypeCastTo<DateTime>() , EndTime = dataRow["END_POINT"].TypeCastTo<DateTime>() });
                    }

                }
            }

            return bookedSlots;
        }

        /// <summary>
        /// generate slots based on doctor aval.
        /// </summary>
        /// <param name="docDayWiseSchedule"></param>
        /// <param name="doctorCode"></param>
        /// <returns></returns>
        private IEnumerable<DateTime> GenerateSchedule(List<DataRow> docDayWiseSchedule, string doctorCode)
        {
            var slots = new List<DateTime>();
            for (var date = DateTime.Now; date.Date <= DateTime.Now.AddMonths(_slotSyncInterval); date = date.AddDays(1).Date)
            {
                var daySchedules = docDayWiseSchedule.Where(row => row.Field<int>("DAY_ID") == (int)date.DayOfWeek);
                foreach (var daySchedule in daySchedules)
                {
                    var slot = new Slot() { StartTime = daySchedule["START_TIME"].TypeCastTo<DateTime>(), EndTime = daySchedule["END_TIME"].TypeCastTo<DateTime>(), DayId = daySchedule["DAY_ID"].TypeCastTo<int>(), Interval = daySchedule["INTERVAL"].TypeCastTo<int>() };
                    var startTime = slot.StartTime.TimeOfDay;
                    var endTime = slot.EndTime.TimeOfDay;
                    var bookedSlots = this.GetDoctorBookedSlotsForDate(doctorCode, date);
                    for (var currTime = startTime; currTime < endTime; currTime = currTime.Add(TimeSpan.FromMinutes(slot.Interval)))
                    {
                        if (bookedSlots != null)
                        {
                            if (!bookedSlots.Any(bkapt => date.Add(currTime) >= bkapt.StartTime && date.Add(currTime) < bkapt.EndTime))
                            {
                                slots.Add(date.Date.Add(currTime));
                            }
                        }
                        else
                        {
                            slots.Add(date.Date.Add(currTime));
                        }

                    }
                }

            }

            return slots;

        }


        /// <summary>
        /// create appointment
        /// </summary>
        /// <param name="patientAppointment"></param>
        public void BookAppointment(Booking patientAppointment)
        {
            //message = "";
            //isSuccess = false;

            try
            {
                var fbParams = new FbParameter[]
                    {
                        new FbParameter("@PATIENT_CODE",DbConstantsHelper.PATIENT_CODE),
                        new FbParameter("@GIVEN_NAME",patientAppointment.FirstName),
                        new FbParameter("@FAMILY_NAME",patientAppointment.LastName),
                        new FbParameter("@DATE_OF_BIRTH",patientAppointment.DateOfBirth),
                        new FbParameter("@MOBILE_PHONE",patientAppointment.Phone)
                    };

                using (var tranScope = new TransactionScope())
                {
                    var patientInsertquery = string.Format(DbConstantsHelper.INSERT_PATIENT, "@PATIENT_CODE", "@GIVEN_NAME", "@FAMILY_NAME", "@DATE_OF_BIRTH", "@MOBILE_PHONE");
                    // create patient info
                    var isPatientSuccess = _syncDbManager.ModifyDataWithQuery(patientInsertquery, fbParams);
                    int patient_gen_id = 0;
                    if (isPatientSuccess)
                    {
                        //get last generated patient id
                        var patientData = _syncDbManager.GetDataWithQuery(DbConstantsHelper.FETCH_PATIENT_GEN_ID);
                        if (patientData != null && patientData.Tables.Count > 0)

                        {
                            if (patientData.Tables[0].Rows.Count > 0)
                            {
                                patient_gen_id = Convert.ToInt32(patientData.Tables[0].Rows[0]["PATINET_ID"]);
                                if (patient_gen_id > 0)
                                {

                                    var apptParams = new FbParameter[]
                                        {
                                       new FbParameter("@DOCTOR_CODE",patientAppointment.CalendarCode),
                                       new FbParameter("@CLINIC_CODE",DbConstantsHelper.CLINIC_CODE),
                                        new FbParameter("@START_POINT",patientAppointment.BookingStartTime),
                                        new FbParameter("@END_POINT",patientAppointment.BookingStartTime.AddMinutes(patientAppointment.Duration)),
                                        new FbParameter("@PATIENT_ID",patient_gen_id),
                                        new FbParameter("@STATUS_CODE",DbConstantsHelper.APPT_STATUS_CODE),
                                        new FbParameter("@APPOINTMENT_TYPE_ID",DbConstantsHelper.APPT_TYPE_ID),
                                        new FbParameter("@STAFF_ID",DbConstantsHelper.STAFF_ID),
                                        new FbParameter("@PATIENT_NAME",patientAppointment.FirstName+", "+patientAppointment.LastName),
                                        new FbParameter("@PATIENT_DOB",patientAppointment.DateOfBirth),
                                        new FbParameter("@BOOKINGTIME",DateTime.Now)

                                        };

                                    var appointmentInsertQuery = string.Format(DbConstantsHelper.INSERT_APPOINTMENT, "@DOCTOR_CODE", "@CLINIC_CODE", "@START_POINT", "@END_POINT", "@PATIENT_ID", "@STATUS_CODE", "@APPOINTMENT_TYPE_ID", "@STAFF_ID", "@PATIENT_NAME", "@PATIENT_DOB", "@BOOKINGTIME");
                                    //create appointment with patient details
                                    var isappointmentSuccess = _syncDbManager.ModifyDataWithQuery(appointmentInsertQuery, apptParams);
                                }
                            }
                        }
                    }

                    tranScope.Complete();
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
