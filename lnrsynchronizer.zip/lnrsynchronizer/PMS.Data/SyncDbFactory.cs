﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Data
{
    public class SyncDbFactory
    {
        /// <summary>
        /// Get Fb DB connection
        /// </summary>
        /// <returns></returns>
        public static FbConnection GetDbConnection()
        {
            return new FbConnection(DbConstantsHelper.PMS_CON_STRING);
        }

        /// <summary>
        /// Get Fb DB command
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="cmdText"></param>
        /// <param name="commandtype"></param>
        /// <returns></returns>
        public static FbCommand GetDbCommand(FbConnection connection, string cmdText, CommandType commandtype)
        {
            var cmd = new FbCommand();
            cmd.Connection = connection;
            cmd.CommandType = commandtype;
            cmd.CommandText = cmdText;
            return cmd;
        }

        /// <summary>
        /// Get Fb DataAdapter
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public static FbDataAdapter GetDbAdapter(FbCommand command)
        {
            return new FbDataAdapter(command);
        }


    }
}
