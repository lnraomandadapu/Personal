﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Data
{
    public class DbConstantsHelper
    {

        #region ConStrings
        public const string PMS_CON_STRING = "User ID=MEDIPAK;Password=xyzzy;Database=FREELANCE04:C:\\Zedmed\\SUPERPLUS;DataSource=localhost;Charset=NONE;";
        #endregion

        public const string FETCH_SCHEDULES_QUERY = "SELECT s.DOCTOR_CODE,td.GIVEN_NAME,td.FAMILY_NAME,ds.start_time, ds.end_time,ds.Day_id, ds.interval from schedules s inner join daily_schedules " +
                "ds on s.schedule_id = ds.schedule_id inner join treating_doctors td on s.DOCTOR_CODE = td.DOCTOR_CODE order by s.DOCTOR_CODE, ds.Day_id";

        public const string INSERT_PATIENT = "INSERT INTO PATIENTS(PATIENT_CODE,GIVEN_NAME,FAMILY_NAME,DATE_OF_BIRTH,MOBILE_PHONE) VALUES({0},{1},{2},{3},{4})";
        public const string FETCH_PATIENT_GEN_ID = "SELECT GEN_ID(PATIENTS, 0) as PATINET_ID FROM RDB$DATABASE";
        public const string INSERT_APPOINTMENT = "INSERT INTO UNIFIED_APPOINTMENTS(DOCTOR_CODE,CLINIC_CODE,START_POINT,END_POINT,PATIENT_ID,STATUS_CODE,APPOINTMENT_TYPE_ID,STAFF_ID,PATIENT_NAME,PATIENT_DOB,BOOKINGTIME) VALUES({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10})";
        public const string FETCH_BOOKED_SLOTS = "SELECT START_POINT,END_POINT  FROM UNIFIED_APPOINTMENTS where DOCTOR_CODE = {0} and START_POINT >= {1}";

        public const string DOCTOR_CODE_PARAM = "@DOCTOR";
        public const string TARGET_DATE_PARAM = "@TARGET_DATE";

        public const int APPT_TYPE_ID = 3;//TODO: New patient
        public const string APPT_STATUS_CODE = "CU";
        public const string CLINIC_CODE = "MED";
        public const string PATIENT_CODE = "P";
        public const string STAFF_ID = "JJ";
    }
}
