﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicBookingSystem.Model.PMSDataAccessWrapper
{
    public interface IPmsSyncDataAccess
    {
        List<PMSCalendarWithSlots> GetCalendarData();
        void BookAppointment(Booking patientAppointment);
    }
}
