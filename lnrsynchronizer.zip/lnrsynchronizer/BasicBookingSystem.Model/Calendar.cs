﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicBookingSystem.Model
{
    public class Calendar
    {
        public int CalendarId { get; set; }

        public string Name { get; set; }

        public string PmsId { get; set; }

        public virtual List<Slot> Slots { get; set; }
    }

    public class PMSCalendarWithSlots
    {
        public string PMSCalendarId { get; set; }

        public string PMSCalendarName { get; set; }

        public string PMSCalendarCode { get; set; }

        public int PMSId { get; set; }

        public IEnumerable<DateTime> Slots { get; set; }
    }
}
