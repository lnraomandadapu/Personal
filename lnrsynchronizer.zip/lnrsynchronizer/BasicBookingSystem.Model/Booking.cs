﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicBookingSystem.Model
{
    public class Booking
    {
        public int BookingId { get; set; }

        public int CalendarId { get; set; }

        public string CalendarName { get; set; }

        public string CalendarCode { get; set; }

        public DateTime BookingStartTime { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public int Duration { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string SyncStatus { get; set; }

        public DateTime SyncStatusLastUpdate { get; set; }

        public string PmsId { get; set; }
    }
}
