﻿using PMS.Business;
using PMS.Business.ApiWrapper;
using PMS.Business.Common;
using System;
using System.Configuration;
using System.ServiceProcess;
using Microsoft.Practices.Unity;

namespace LNRSynchronizer
{
    public partial class PmsSync : ServiceBase
    {
        System.Timers.Timer timeDelay;
        IClientApiWrapper _client = null;
        private static object _intervalSync = new object();

        public PmsSync()
        {
            InitializeComponent();
            _client = UnityConfig.UnityContainer.Resolve<IClientApiWrapper>();
            timeDelay = new System.Timers.Timer();
            timeDelay.Enabled = true;
            timeDelay.Interval = 1000 * this.ScheduleInterval();
            timeDelay.Elapsed += new System.Timers.ElapsedEventHandler(WorkProcess);
        }

        private int ScheduleInterval()
        {
            var scheduleInterval = ConfigurationManager.AppSettings["IntervalSeconds"];
            return scheduleInterval == null ? 60 : Convert.ToInt32(scheduleInterval);
        }

        private void WorkProcess(object sender, System.Timers.ElapsedEventArgs e)
        {
            Logger.Info("Data Refresh start at : " + DateTime.Now);

            if (System.Threading.Monitor.TryEnter(_intervalSync))
            {
                try
                {
                    _client.RefreshData();
                    _client.UpdateUnSyncDataToPMS();
                }
                finally
                {
                    System.Threading.Monitor.Exit(_intervalSync);
                }
            }
            else
            {
                Logger.Info("Data Refresh skipped at : " + DateTime.Now);
            }
            Logger.Info("Data Refresh end at : " + DateTime.Now);

        }
#if (DEBUG)
        public void RefreshDataFromPms()
        {
            Logger.Info("Data Refresh start at : " + DateTime.Now);


            if (System.Threading.Monitor.TryEnter(_intervalSync))
            {
                try
                {
                    _client.RefreshData();
                    _client.UpdateUnSyncDataToPMS();
                }
                finally
                {
                    System.Threading.Monitor.Exit(_intervalSync);
                }
            }
            else
            {
                //Previous interval is still in progress.
            }
            Logger.Info("Data Refresh end at : " + DateTime.Now);
        }
#endif

        protected override void OnStart(string[] args)
        {
            timeDelay.Enabled = true;
            Logger.Info("Service Started at: " + DateTime.Now);
        }

        protected override void OnStop()
        {
            timeDelay.Enabled = false;
            Logger.Info("Service Stopped at: " + DateTime.Now);
        }


    }
}
