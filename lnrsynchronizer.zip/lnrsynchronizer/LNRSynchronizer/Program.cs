﻿using PMS.Business;
using PMS.Business.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace LNRSynchronizer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            string dataDLL = ConfigurationManager.AppSettings["PMSDataDll"];
            if (string.IsNullOrEmpty(dataDLL))
            {
                Logger.Error("Configuration issue, unable to load PMS data dll");
                return;
            }
            UnityConfig.RegisterComponents(dataDLL);

#if (!DEBUG)
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new PmsSync()
            };
            ServiceBase.Run(ServicesToRun);
#else
            PmsSync sync = new PmsSync();
            sync.RefreshDataFromPms();
    #endif
        }
    }
}
