﻿namespace PMS.DependencyResolver
{
    public interface IRegisterComponent
    {

        /// <summary>
        /// Register type method
        /// </summary>
        /// <typeparam name="TFrom"></typeparam>
        /// <typeparam name="TTo"></typeparam>
        void RegisterType<TFrom, TTo>() where TTo : TFrom;

        /// <summary>
        /// Register type with container controlled life time manager
        /// </summary>
        /// <typeparam name="TFrom"></typeparam>
        /// <typeparam name="TTo"></typeparam>
        void RegisterTypeWithControlledLifeTime<TFrom, TTo>() where TTo : TFrom;
    }
}
