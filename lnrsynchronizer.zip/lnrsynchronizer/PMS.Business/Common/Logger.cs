﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Business.Common
{
    public static class Logger
    {
        private static readonly log4net.ILog logger = log4net.LogManager.GetLogger
    (System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static Logger()
        {
            // Log = log4net.LogManager.GetLogger(typeof(Logger));
        }

        public static void Error(object msg)
        {
            logger.Error(msg);
        }

        public static void Error(object msg, Exception ex)
        {
            logger.Error(msg, ex);
        }

        public static void Error(Exception ex)
        {
            logger.Error(ex.Message, ex);
        }

        public static void Info(object msg)
        {
            logger.Info(msg);
        }
    }
}
