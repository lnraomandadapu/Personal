﻿using BasicBookingSystem.Model;
using Newtonsoft.Json;
using PMS.Business.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
using BasicBookingSystem.Model.PMSDataAccessWrapper;

namespace PMS.Business.ApiWrapper
{
    public class ClientApiWrapper : IClientApiWrapper
    {
        private IPmsSyncDataAccess _pmsSyncDataAccess = null;
        private int _httpClientCallTimeOut = 0;

        public ClientApiWrapper()
        {
            _pmsSyncDataAccess = UnityConfig.UnityContainer.Resolve<IPmsSyncDataAccess>();
            _httpClientCallTimeOut = Helper.GetAppSetting("ApiTimeOutMintues").TypeCastTo<int>();
        }

        /// <summary>
        /// update unsync appointments info
        /// </summary>
        public void UpdateUnSyncDataToPMS()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Helper.GetAppSetting("BaseAddress"));
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    if (_httpClientCallTimeOut > 0)
                    {
                        client.Timeout = new TimeSpan(0, _httpClientCallTimeOut, 0);
                    }

                    HttpResponseMessage response = client.GetAsync(Helper.GetAppSetting("ClientApiSyncData")).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var bookings = response.Content.ReadAsAsync<IEnumerable<Booking>>().Result;
                        foreach (var booking in bookings)
                        {
                            this.UpdateBooking(booking);
                        }
                    }
                    else
                    {
                        var exception = new Exception(response.Content.ReadAsStringAsync().Result);
                        Logger.Error("Error while getting unsync data at : " + DateTime.Now, exception);
                    }
                }

            }
            catch (Exception ex)
            {

                Logger.Error("Error while getting unsync data at : " + DateTime.Now, ex);
            }
        }

        /// <summary>
        /// create appointment in PMS and update the booking status
        /// </summary>
        /// <param name="booking"></param>
        private void UpdateBooking(Booking booking)
        {
            try
            {
                var values = new Dictionary<string, string>();
                values.Add("bookingId", booking.BookingId.ToString());
                values.Add("pmsId",Helper.GetAppSetting("PmsId"));
                var content = new FormUrlEncodedContent(values);

                _pmsSyncDataAccess.BookAppointment(booking);

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(Helper.GetAppSetting("BaseAddress"));
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    if (_httpClientCallTimeOut > 0)
                    {
                        client.Timeout = new TimeSpan(0, _httpClientCallTimeOut, 0);
                    }
                    var uri = Helper.GetAppSetting("ClientApiSyncData") + "?bookingId=" + booking.BookingId.ToString() + "&pmsId=" + Helper.GetAppSetting("PmsId");
                    var postTask = client.PostAsync(uri, content);
                    var httpResponseMessage = postTask.Result;
                    if (!httpResponseMessage.IsSuccessStatusCode)
                    {
                        var exception = new Exception(httpResponseMessage.Content.ReadAsStringAsync().Result);
                        Logger.Error("Error while updating the booking: " + DateTime.Now, exception);
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.Error("Error while updating the booking: " + DateTime.Now, ex);
            }

        }

        /// <summary>
        /// refresh doctors and slots info
        /// </summary>
        public void RefreshData()
        {

            try
            {
                var calendarData = _pmsSyncDataAccess.GetCalendarData();

                if (calendarData != null)
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(Helper.GetAppSetting("BaseAddress"));
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        if (_httpClientCallTimeOut > 0)
                        {
                            client.Timeout = new TimeSpan(0, _httpClientCallTimeOut, 0);
                        }

                        var calendarContent = JsonConvert.SerializeObject(calendarData);
                        StringContent content = new StringContent(calendarContent, Encoding.UTF8, "application/json");

                        var postTask = client.PostAsync(Helper.GetAppSetting("ClientApiDataRefresh"), content);
                        var response = postTask.Result;
                        if (response.IsSuccessStatusCode)
                        {
                            Logger.Info("Calendar and Slots info refreshed at: " + DateTime.Now);
                        }
                        else
                        {
                            var exception = new Exception(response.Content.ReadAsStringAsync().Result);
                            Logger.Error("Error while Calendar and Slots info refresh at: " + DateTime.Now, exception);
                        }
                    }


                }
            }
            catch (Exception ex)
            {

                Logger.Error("Error while Calendar and Slots info refresh at: " + DateTime.Now, ex);
            }
        }


    }
}
