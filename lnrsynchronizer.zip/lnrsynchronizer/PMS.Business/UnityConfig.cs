﻿using Microsoft.Practices.Unity;
using PMS.Business.ApiWrapper;
using PMS.DependencyResolver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Business
{
    public static class UnityConfig
    {

        public static UnityContainer UnityContainer;

        public static void RegisterComponents(string dllPath)
        {
            UnityContainer = new UnityContainer();
            UnityContainer.RegisterType<IClientApiWrapper, ClientApiWrapper>();
            var path = AppDomain.CurrentDomain.BaseDirectory;
            ComponentLoader.LoadContainer(UnityContainer, path, dllPath);
        }
    }
}
